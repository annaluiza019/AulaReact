export default function App()
{
    return (
        <div>
            <h1>Estudo CSS</h1>
            
        </div>
    );
}